const ProtectedRoutes = () => {
  return (
    <>
      <div></div>
    </>
  );
};
