const Downloads = () => (
  <>
    <div
      style={{
        margin: "2rem auto",
        width: "fit-content",
        fontSize: "30px",
      }}
    >
      Download Page
    </div>
  </>
);

export default Downloads;
