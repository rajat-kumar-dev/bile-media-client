const RateUs = () => {
  return "rate us page";
};

export default RateUs;
