import React from "react";
const GlobalContext = React.createContext();
export default GlobalContext;
